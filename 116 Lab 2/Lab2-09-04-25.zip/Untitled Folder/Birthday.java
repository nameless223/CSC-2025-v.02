public class Birthday 
{
    public static void main(String []args)
    {
        String date1 = (02 + "/" + 02);
        String date2 = (06 + "/" + 19);
        

        System.out.println("My birthday is " + date1 + ", and Suzy's is " + date2);
    }
}
