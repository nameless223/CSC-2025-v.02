public class Oops 
{
    public static void main(String[] args) 
    {
        double x = 0.0;
        System.out.println("x is" + x);

        x = 15.2;       // set x to 15.2
        System.out.println("x is now " + x);

        double y = 0.0;       // set y to 1 more than x
        y = x + 1;
        System.out.println("x and y are " + x + " and " + y);
    }
}